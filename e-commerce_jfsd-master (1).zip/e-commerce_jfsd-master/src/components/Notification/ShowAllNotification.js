import React from 'react'

function ShowAllNotification() {
  return (
    <div>ShowAllNotification</div>
  )
}

export default ShowAllNotification