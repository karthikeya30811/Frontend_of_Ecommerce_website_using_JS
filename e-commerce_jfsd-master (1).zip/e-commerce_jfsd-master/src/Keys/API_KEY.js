const api_key = "4N9jvDnwnxSEN4lqkBHiVQ8SZXS3KWSUJnz";
export default api_key; 